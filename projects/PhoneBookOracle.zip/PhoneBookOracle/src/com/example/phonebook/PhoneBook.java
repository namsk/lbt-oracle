package com.example.phonebook;

public class PhoneBook {

	public static void main(String[] args) {

	}

}
